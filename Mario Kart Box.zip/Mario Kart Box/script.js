// Global Variables

let numBanana = 0;
let numShell = 0;
let numStar = 0;
let numMushroom = 0;
let numBullet = 0;

// Event Listener
  $("#roll").click(rollBox);

// Event Function

  function rollBox() {
    let randNum = Math.random();
    let position = $("#position").val();

    if (position =< 6) {
      if (randNum < 0.45) {
        numBanana++
        $("#banana").html(numBanana);
      } else if (randNum < 0.8) {
        numShell++
        $("#shell").html(numShell);
      } else if (randNum < 0.95) {
        numStar++
        $("#star").html(numStar);
      } else if (randNum < 0.99) {
        numMushroom++
        $("#mushroom").html(numMushroom);
      } else {
        numBullet++
        $("#bullet").html(numBullet);
      }
    } else if (position =< 12) {
      if (randNum < 0.05) {
        numBanana++
        $("#banana").html(numBanana);
      } else if (randNum < 0.1) {
        numShell++
        $("#shell").html(numShell);
      } else if (randNum < 0.35) {
        numStar++
        $("#star").html(numStar);
      } else if (randNum < 0.7) {
        numMushroom++
        $("#mushroom").html(numMushroom);
      } else {
        numBullet++
        $("#bullet").html(numBullet);
    }  
    
  }