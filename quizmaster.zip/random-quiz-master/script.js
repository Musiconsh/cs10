// TITLE
"use strict"; // Use strict mode

// Select all the Elements
let $markBtn = $("#mark");
let $q1Input = $("#q1 input");
let $q1Result = $("#q1 span");
let $q2Input = $("#q2 input");
let $q2Result = $("#q2 span");
let $q3Input = $("#q3 input");
let $q3Result = $("#q3 span");
let $q4Input = $("#q4 input");
let $q4Result = $("#q4 span");
let $results = $("#results");
let $feedback = $("#feedback")

// Add Event Listener
$markBtn.on("click", markQuiz);

// Event Functions
function markQuiz() {
	//Intialize a Score Variable
	let score = 0;
	
	// Check Question 1
	let answer = $q1Input.val();
	answer = answer.toLowerCase();
	if (answer === "the king" || answer === "king") {
		$q1Result.html("Correct");
		score = score +1;
	} else {
		$q1Result.html("Incorrect");
	}
	// Check Question 2
	answer = $q2Input.val();
	if (answer != 2) {
		$q2Result.html("Correct");
		score = score +1;
	} else {
		$q2Result.html("Incorrect");
	}
	// Check Question 3
	answer = $q3Input.val();
	if (answer <= 0) {
		$q3Result.html("Correct");
		score = score +1;
	} else {
		$q3Result.html("Incorrect");
	}
	// Check Question 4
	answer = $q4Input.val();
	if (answer >= 5 && answer <= 15) {
		$q4Result.html("Correct");
		score = score +1;
	} else {
		$q4Result.html("Incorrect");
	}
	
	// Output Results
	$results.html("Your score is " + score + " out of 4")
	
	if (score === 4) {
		$feedback.html("Great Job!");
	} else if (score === 3) {
		$feedback.html("Great Job!")
	} else if(score === 2) {
		$feedback.html("Alright!")
	} else if(score === 1) {
		$feedback.html("Ouch")
	}
}
