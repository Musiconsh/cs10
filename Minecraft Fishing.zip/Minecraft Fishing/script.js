// TITLE
"use strict"; // Use strict mode

// Global Variables
let numFish = 0;
let numJunk = 0;
let numTreasure = 0;
let numSalmon = 0;
let numPuffer = 0;
let numClown = 0;
let timer;

// Add Event Listener
$("#main").mousedown(setFishTimer);
$("#main").mouseup(cancelFishTimer)

//Event Functions
function setFishTimer() {
	let randTime = Math.random() * 7000 + 3000;
	timer = setTimeout(catchFish, randTime);
}

function cancelFishTimer() {
	clearTimeout(timer);
}

function catchFish() {

	// Use a random number to simulate results
	let randNum = Math.random(); // B/T 0 and 1

	// Output Results
	if (randNum < 0.85) {
		let randFish = Math.random();
		if (randFish < 0.6) {
			$("#results").append("<img src='Images/RawFish.png'>")
			numFish++
			$("#fish").html(numFish);
		} else if (randFish < 0.85) {
			$("#results").append("<img src='Images/RawSalmon.png'>")
			numSalmon++
			$("#salmon").html(numSalmon);
		} else if (randFish < 0.87) {
			$("#results").append("<img src='Images/Clownfish.png'>")
			numClown++
			$("#clown").html(numClown);
		} else {
			$("#results").append("<img src='Images/pufferfish_2.png'>")
			numPuffer++
			$("#puffer").html(numPuffer);
		}
	} else if (randNum < 0.95) {
		$("#results").append("<img src='Images/download.png'>")
		numJunk++
		$("#junk").html(numJunk);
	} else {
		$("#results").append("<img src='Images/PE_Bow_Pull_2.png'>")
		numTreasure++
		$("#treasure").html(numTreasure);
	}

}
