function platformSetup() {
	fill(255)
	rect(0, 500, 800, 200)
	rect(100, 400, 80, 15)
	rect(280, 300, 80, 15)
}