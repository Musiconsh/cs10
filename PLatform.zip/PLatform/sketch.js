// P5.JS TEMPLATE
var moveX = 400
var moveY = 480
var gravity = 0.1
// SETUP FUNCTION - Runs once at beginning of program
function setup() {
	createCanvas(800, 600);
	
}

// DRAW FUNCTION - Loops @ 60FPS by default
function draw() {
	
	background(0)
	platformSetup()
	// Player
	rect(moveX, moveY, 20, 20);
	// Movement
	if (keyIsDown(LEFT_ARROW)) {
		moveX = moveX - 5
	} else if (keyIsDown(RIGHT_ARROW)) {
		moveX = moveX + 5
	}
}

function keyPressed() {
	if (keyIsDown(UP_ARROW)) {
		moveY = moveY - 100
	}
}
